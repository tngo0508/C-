/***********************************************

	Class DoublyList

************************************************/

#include "DoublyList.h"

#include <iostream>
using namespace std;

int main()
{
	DoublyList intList;

	//Your testing cases

	cout << endl << endl;
	system("Pause");
	return 0;
}
