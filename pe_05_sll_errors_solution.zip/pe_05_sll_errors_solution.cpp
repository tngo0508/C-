#include "AnyList.h"

AnyList::AnyList()
{
	first = NULL;
	/*** ADDED ***/ count = 0;
}

void AnyList::insertFront(int newData)
{	
	Node *newNode;	
	/*** ADDED ***/ newNode = new Node;
	newNode->setData(newData);	
	newNode->setLink(first);	
	first = newNode;	
	/*** ADDED ***/ ++count;


	/*
		Better way:
			Node *newNode = new Node(newData, first);
			first = newNode;
			++count;

		OR even better:
			first = newNode(newData, first);
			++count;
	*/

}

//*** ERROR *** void deleteNode(int deleteData)
void AnyList::deleteNode(int deleteData)
{
	if (count == 0)
		cerr << "Cannot delete from an empty list.\n";
	/*** ADDED ***/ else
	{
		/*** INITILIAZED HERE ***/ Node *current = first;
		//*** OMITTED - Not needed yet *** Node *temp;
		bool found = false;		

		if (first->getData() == deleteData)  
		{
			
			first = first->getLink();
			//*** INITILIAZED ABOVE *** current = first;			
			delete current;
			current = NULL;
			found = true;
			/*** ADDED ***/ --count;
		}
		else
		{
			//*** CHANGED *** temp = first;
			/*** ADDED ***/ Node *temp = first;

			//*** ERROR *** while ((current != NULL) || (!found))
			while ((current != NULL) && (!found))
			{
				if (current->getData() == deleteData)
				{
					temp->setLink(current->getLink());
					delete current;
					current = NULL;
					found = true;
					/*** ADDED ***/ --count;
				}
				else
				{
					/*** ADDED ***/ temp = current;
					current = current->getLink();
				}
			}
		}
		
		if (!found)
			cerr << "Item to be deleted is not in the list." << endl;

	/*** ADDED TO COMPLETE ELSE STATEMENT ***/	}
}

//*** ERROR *** void AnyList::print() 
void AnyList::print() const
{
	/*** RE-ARRANGED 
		Node *current;
		current = first;
	***/
	Node *current = first;	

	//*** ERROR *** while (current->getLink() != NULL)
	while (current != NULL)
	{
		cout << current->getData() << " ";
		current = current->getLink();
	
	/*** ADDED ***/	}

}

void AnyList::destroyList()
{ 
	//*** ERROR *** Node  *temp = NULL;
	Node  *temp = first;
	
    while (temp != NULL)
    {
        first = first->getLink();
		//*** ERROR ***  delete first;
		delete temp;
		temp = first;
    }

	/*** ADDED ***/	count = 0;
}

AnyList::~AnyList()
{
	destroyList();
}