#include "DoublyList.h"

DoublyList::DoublyList()
{
	first = NULL;
	last = NULL;
	count = 0;
}

DoublyList::~DoublyList()
{
	destroyList();
}

void DoublyList::insertBack(int newData)
{
	Node *newNode;
	// *** ERROR ***   *newNode = new Node;
	newNode = new Node;

	newNode->setData(newData);

	/*
		Better way:
			
			Node *newNode = new Node(newData, NULL);

	*/

	if (first == NULL)
	{
		first = newNode;
		/*** MISSING ***/ last = newNode;
	}
	else
	{
		last->setNextLink(newNode);
		newNode->setPreviousLink(last);
		/*** MISSING ***/ last = newNode;
	}

	/*** MISSING ***/ ++count;

}

	//search
bool DoublyList::search(int searchData) const
{
    Node *current = first;	

    while (current != NULL)	
	{		
		// *** ERROR ***   if (current->getData() = searchData)
		if (current->getData() == searchData)
			return true;
        else
            current = current->getNextLink();	
	}

	/*** MISSING ***/ return false; 
	/*
		Not returning from all paths produces a WARNING.
		A warning IS an error.
	*/
}

	//deleteNode
void DoublyList::deleteNode(int deleteData) 
{
    if (first == NULL)		
	{
        cerr << "Cannot delete from an empty list." << endl;
	}
    else  
    {
		// Node *current;	=> Should be initialized here
		/*** ADDED ***/ Node *current = first;

        if (first->getData() == deleteData)   
		{
			//*** OMITTED - Initialized above *** current = first;
			first = first->getNextLink();	

			if (first == NULL)	last = NULL;				
			/*** ADDED ***/ else first->setPreviousLink(NULL);
				
			/*** ADDED ***/ --count;
			delete current;
			current = NULL;		
		}
		else 
		{
			bool found = false;		
							
			//*** OMITTED - Initialized above *** current = first;	

			// *** ERROR ***    while (current != NULL || !found) 
			while (current != NULL && !found) 
			{								  

				if (current->getData() == deleteData) 
					found = true;					  
				else
					current = current->getNextLink(); 
			}

			if (current == NULL)	
				cerr << "The item to be deleted is not in the list." << endl;
			else         
			{
				if (current != last)		
				{
					current->getPreviousLink()->setNextLink(current->getNextLink());
					/*** ADDED ***/ current->getNextLink()->setPreviousLink(current->getPreviousLink());
				}				
				else
				{
					last = current->getPreviousLink();			
					/*** ADDED ***/ last->setNextLink(NULL);
				}

				--count;
				delete current;
				current = NULL;
			}
		}
	}	
}

// *** ERROR ***   void print() const
void DoublyList::print() const
{
	if (count == 0)
		cerr << "List is empty. Cannot print." << endl;
	else
	{
		Node *temp = first;

		// *** ERROR ***   while (first != NULL)
		while (temp != NULL)
		{
			cout << temp->getData() << " ";
			temp = temp->getNextLink();
		}
		cout << endl;
	}	
}

// *** ERROR ***   void DoublyList::reversePrint() 
void DoublyList::reversePrint() const
{
	if (count == 0)
		cerr << "List is empty. Cannot print." << endl;
	else
	{
		Node *temp = last;

		// *** ERROR ***   while (last != NULL)
		while (temp != NULL)
		{
			cout << temp->getData() << " ";
			temp = temp->getPreviousLink();
		}
		cout << endl;
	}
}

void DoublyList::destroyList()
{ 
    /*
	
	Node  *temp;
	
    while (first != NULL)
    {
		first = temp;
		temp = first;
        temp = temp->getNextLink();
        delete first;
		first = NULL;
    }

	last = NULL;	
	count = 0;

	*/

	// RE-ARRANGED

	Node *temp = first;

	while (first != NULL)
	{
		first = first->getNextLink();
		delete temp;
		temp = first;
	}

	count = 0;
}
